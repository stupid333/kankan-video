import video from './video'

export default {
  video,
}

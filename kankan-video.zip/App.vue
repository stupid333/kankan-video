<script>
</script>

<style lang="scss">
/* #ifdef APP-VUE */
@import 'uview-ui/index.scss';
@import './common/css/uni.css';
/* #endif */
</style>
